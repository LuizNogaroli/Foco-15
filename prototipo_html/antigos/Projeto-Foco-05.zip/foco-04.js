/**
 * foco-04.js
 * Lógica de interatividade para a Etapa 4: Análise do Imóvel
 */

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('form04');
    if (!form) return;

    function initCondicionais(index) {
        // 1. Situação Ocupacional -> Obs
        const selOcup = document.getElementById(`campo31_${index}`);
        const blocoObsOcup = document.getElementById(`bloco-obs31_${index}`);
        if (selOcup && blocoObsOcup) {
            selOcup.addEventListener('change', () => {
                const precisaObs = ['Ocupado irregularmente', 'Em disputa judicial', 'Parcialmente ocupado'].includes(selOcup.value);
                blocoObsOcup.style.display = precisaObs ? 'flex' : 'none';
            });
        }

        // 2. Incidência Ambiental (Checkbox) -> Obs
        const containerAmb = document.getElementById(`group-incidencia_${index}`);
        const blocoObsAmb = document.getElementById(`bloco-obs35_${index}`);
        if (containerAmb && blocoObsAmb) {
            containerAmb.addEventListener('change', () => {
                const chkOutra = document.getElementById(`chk-outra-ambiental_${index}`);
                blocoObsAmb.style.display = (chkOutra && chkOutra.checked) ? 'flex' : 'none';
            });
        }

        // 3. Custos SPU -> Valor
        const radiosCustos = document.querySelectorAll(`input[name="imoveis[${index}][custos_manutencao]"]`);
        const blocoValor = document.getElementById(`bloco-obs37_${index}`);
        radiosCustos.forEach(r => {
            r.addEventListener('change', () => {
                blocoValor.style.display = (r.value === 'Sim' && r.checked) ? 'flex' : 'none';
            });
        });

        // 4. Risco Invasão -> Desc
        const radiosInvasao = document.querySelectorAll(`input[name="imoveis[${index}][risco_invasao]"]`);
        const blocoDescInvasao = document.getElementById(`bloco-desc38_${index}`);
        radiosInvasao.forEach(r => {
            r.addEventListener('change', () => {
                blocoDescInvasao.style.display = (r.value === 'Sim' && r.checked) ? 'flex' : 'none';
            });
        });

        // 5. Risco Coletividade -> Desc
        const radiosCol = document.querySelectorAll(`input[name="imoveis[${index}][risco_coletividade]"]`);
        const blocoDescCol = document.getElementById(`bloco-desc39_${index}`);
        radiosCol.forEach(r => {
            r.addEventListener('change', () => {
                blocoDescCol.style.display = (r.value === 'Sim' && r.checked) ? 'flex' : 'none';
            });
        });

        // 6. Restrições (Checkboxes) -> Obs
        const containerRest = document.getElementById(`group-restricoes_${index}`);
        const blocoObsRest = document.getElementById(`bloco-obs-restricoes_${index}`);
        if (containerRest && blocoObsRest) {
            containerRest.addEventListener('change', () => {
                const algumMarcado = Array.from(containerRest.querySelectorAll('input[type="checkbox"]')).some(cb => cb.checked);
                blocoObsRest.style.display = algumMarcado ? 'flex' : 'none';
            });
        }

        // 7. Lista Dinâmica de Documentos (CORREÇÃO)
        const btnAddDoc = document.getElementById(`btnAdicionarImagemIdent_${index}`);
        const listDoc = document.getElementById(`imagens-list-ident_${index}`);

        if (btnAddDoc && listDoc) {
            btnAddDoc.addEventListener('click', () => {
                const row = document.createElement('div');
                row.className = 'imagem-item';
                row.style.cssText = 'display:flex; gap:8px; align-items:center; margin-top:8px;';
                row.innerHTML = `
                    <input type="text" name="imoveis[${index}][links][]" placeholder="Link/Documento Anexado" class="imagem-input" style="flex: 1;">
                    <button type="button" class="btn-remove-imagem" title="Remover">✕</button>
                `;
                listDoc.appendChild(row);
                row.querySelector('input').focus();
                row.querySelector('.btn-remove-imagem').addEventListener('click', () => row.remove());
            });
        }
    }

    // Inicializa bloco 0
    initCondicionais(0);

    // Reaplica máscaras
    if (typeof autoInitMasks === 'function') {
        autoInitMasks();
    }

    // Submit
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('✅ Análise do Imóvel salva com sucesso!');
    });

    // Limpar
    document.getElementById('btnLimpar').addEventListener('click', () => {
        if (confirm('Deseja limpar todos os campos?')) {
            form.reset();
            document.querySelectorAll('[id^="bloco-"]').forEach(b => b.style.display = 'none');
            document.querySelectorAll('[id^="imagens-list-"]').forEach(l => l.innerHTML = '');
        }
    });
});
