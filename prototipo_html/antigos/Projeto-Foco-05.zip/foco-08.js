/**
 * foco-08.js
 * Otimização técnica mantendo layout e conteúdo originais
 */

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('form08');
    if (!form) return;

    // --- 1. GESTÃO DE ASSINATURAS (PADRÃO UNIFICADO) ---
    function setupAssinatura(suffix) {
        const els = {
            wrapper: document.getElementById(`acordeao-${suffix}`),
            header: document.getElementById(`acordeao-header-${suffix}`),
            btnAssinar: document.getElementById(`btn-assinar-${suffix}`),
            btnLimpar: document.getElementById(`btn-limpar-${suffix}`),
            badgeOk: document.getElementById(`badge-${suffix}-ok`),
            badgePend: document.getElementById(`pendente-${suffix}`),
            status: document.getElementById(`status-${suffix}`),
            flag: document.getElementById(`flag-${suffix}`),
            conteudo: document.getElementById(`conteudo-${suffix}`)
        };

        if(!els.header) return;

        els.header.addEventListener('click', () => els.wrapper.classList.toggle('aberto'));

        els.conteudo.addEventListener('change', () => {
            if(els.flag.value === "0") els.btnAssinar.disabled = false;
        });

        els.btnAssinar.addEventListener('click', () => {
            els.flag.value = "1";
            els.badgeOk.classList.add('visivel');
            if(els.badgePend) els.badgePend.classList.add('oculto');
            if(els.status) els.status.classList.add('visivel');
            els.btnAssinar.style.display = 'none';
            els.btnLimpar.style.display = 'inline-block';
            els.conteudo.classList.add('decl-conteudo-bloqueado');
            els.conteudo.querySelectorAll('input, textarea').forEach(i => i.disabled = true);
        });

        els.btnLimpar.addEventListener('click', () => {
            els.flag.value = "0";
            els.badgeOk.classList.remove('visivel');
            if(els.badgePend) els.badgePend.classList.remove('oculto');
            if(els.status) els.status.classList.remove('visivel');
            els.btnAssinar.style.display = 'inline-block';
            els.btnLimpar.style.display = 'none';
            els.conteudo.classList.remove('decl-conteudo-bloqueado');
            els.conteudo.querySelectorAll('input, textarea').forEach(i => i.disabled = false);
            els.btnAssinar.disabled = true;
        });
    }

    ['A', 'B', 'C'].forEach(setupAssinatura);

    // --- 2. LÓGICA CONDICIONAL DE BLOCOS ---
    const toggleBloco = (radioName, blocoId, value = 'condicionantes') => {
        document.querySelectorAll(`input[name="${radioName}"]`).forEach(r => {
            r.addEventListener('change', () => {
                const bloco = document.getElementById(blocoId);
                if(bloco) bloco.style.display = r.value === value ? 'block' : 'none';
            });
        });
    };

    toggleBloco('A_manifestacao_final', 'bloco-A-condicionantes', 'condicionantes');
    toggleBloco('decl_B_opcao', 'bloco-B-condicionantes', 'condicionantes');

    // --- 3. ADICIONAR CONDICIONANTES DINÂMICAS (SEÇÃO B) ---
    const btnAddB = document.getElementById('btn-add-cond-B');
    const listaB = document.getElementById('B-condicionantes-lista');
    let countB = 1;

    if(btnAddB && listaB) {
        btnAddB.addEventListener('click', () => {
            countB = listaB.querySelectorAll('.condicionante-row').length + 1;
            const row = document.createElement('div');
            row.className = 'condicionante-row';
            row.innerHTML = `<span>Condicionante ${countB}</span><textarea name="B_condicionante[]"></textarea>`;
            listaB.appendChild(row);
        });
    }

    // --- 4. MODAL E ENVIO ---
    const modal = document.getElementById('modalEnvio');
    const btnFechar = document.getElementById('btnFecharModal');

    document.getElementById('btnEnviarCDE')?.addEventListener('click', () => {
        if(document.getElementById('flag-C').value !== "1") {
            alert('⚠️ A manifestação da Diretoria (Seção C) é obrigatória antes do envio.');
            return;
        }
        if(modal) modal.style.display = 'flex';
    });

    if(btnFechar) btnFechar.addEventListener('click', () => modal.style.display = 'none');

    document.getElementById('btnLimparGlobal')?.addEventListener('click', () => {
        if(confirm('Deseja limpar todo o formulário?')) location.reload();
    });
});
