/**
 * foco-07.js
 * Lógica restaurada e aprimorada da Etapa 7
 * Gerencia Seções A, B e C com caminhos condicionais e Modal
 */

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('form07');
    if (!form) return;

    // --- 1. CONFIGURAÇÃO PADRÃO DE SEÇÕES DE ASSINATURA ---
    function setupAssinatura(suffix) {
        const wrapper = document.getElementById(`acordeao-${suffix}`);
        const header = document.getElementById(`acordeao-header-${suffix}`);
        const btnAssinar = document.getElementById(`btn-assinar-${suffix}`);
        const btnLimpar = document.getElementById(`btn-limpar-${suffix}`);
        const badgeOk = document.getElementById(`badge-${suffix}-ok`);
        const badgePend = document.getElementById(`pendente-${suffix}`);
        const status = document.getElementById(`status-${suffix}`);
        const overlay = document.getElementById(`overlay-${suffix}`);
        const resumo = document.getElementById(`resumo-${suffix}`);
        const flag = document.getElementById(`flag-${suffix}`);
        const conteudo = document.getElementById(`conteudo-${suffix}`);

        // Toggle Acórdão
        header.addEventListener('click', () => wrapper.classList.toggle('aberto'));

        // Habilita assinatura ao interagir com conteúdo
        conteudo.addEventListener('change', () => {
            if(flag.value === "0") btnAssinar.disabled = false;
        });

        // Assinar
        btnAssinar.addEventListener('click', () => {
            flag.value = "1";
            badgeOk.classList.add('visivel');
            if(badgePend) badgePend.classList.add('oculto');
            status.classList.add('visivel');
            if(overlay) overlay.classList.add('visivel');
            if(resumo) resumo.textContent = "Manifestação registrada com sucesso.";
            btnAssinar.style.display = 'none';
            btnLimpar.style.display = 'inline-block';
            
            // Bloqueio
            conteudo.classList.add('decl-conteudo-bloqueado');
            conteudo.querySelectorAll('input, textarea, select').forEach(i => i.disabled = true);
        });

        // Limpar Assinatura
        btnLimpar.addEventListener('click', () => {
            flag.value = "0";
            badgeOk.classList.remove('visivel');
            if(badgePend) badgePend.classList.remove('oculto');
            status.classList.remove('visivel');
            if(overlay) overlay.classList.remove('visivel');
            btnAssinar.style.display = 'inline-block';
            btnLimpar.style.display = 'none';
            
            conteudo.classList.remove('decl-conteudo-bloqueado');
            conteudo.querySelectorAll('input, textarea, select').forEach(i => i.disabled = false);
            btnAssinar.disabled = true;
        });
    }

    // Inicializa seções A e B
    setupAssinatura('A');
    setupAssinatura('B');
    setupAssinatura('C');

    // --- 2. LÓGICA CONDICIONAL SEÇÃO C (SUPERINTENDÊNCIA) ---
    const cdeRadios = document.querySelectorAll('input[name="cde_manifestacao"]');
    const blocoSim = document.getElementById('bloco-C-cde-sim');
    const blocoNao = document.getElementById('bloco-C-cde-nao');

    cdeRadios.forEach(r => {
        r.addEventListener('change', () => {
            blocoSim.style.display = r.value === 'sim' ? 'block' : 'none';
            blocoNao.style.display = r.value === 'nao' ? 'block' : 'none';
        });
    });

    // --- 3. MODAL DE CONFIRMAÇÃO E ENVIO ---
    const modal = document.getElementById('modalEnvio');
    const btnFecharModal = document.getElementById('btnFecharModal');

    document.getElementById('btnEnviarUC')?.addEventListener('click', () => {
        const flagA = document.getElementById('flag-A').value;
        const flagB = document.getElementById('flag-B').value;
        const flagC = document.getElementById('flag-C').value;

        if(flagA !== "1" || flagC !== "1") {
            alert('⚠️ A manifestação da Chefia e da Superintendência são obrigatórias antes do envio.');
            return;
        }
        
        if (modal) modal.style.display = 'flex';
    });

    if (btnFecharModal) {
        btnFecharModal.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    }

    // --- 4. LIMPAR GLOBAL ---
    document.getElementById('btnLimparGlobal')?.addEventListener('click', () => {
        if(confirm('Deseja limpar todo o formulário?')) location.reload();
    });

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('✅ Rascunho salvo!');
    });
});
