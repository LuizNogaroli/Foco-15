/**
 * Gerenciamento de Navegação via Iframe e URL Hash
 */

document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('.circle-btn');
    const iframe = document.getElementById('frame');

    /**
     * Carrega a página com base no botão clicado ou no Hash da URL
     * @param {string} url - Caminho do arquivo .html
     * @param {HTMLElement} element - O botão que foi clicado
     */
    function navigate(url, element) {
        if (!url) return;

        // Atualiza o iframe
        iframe.src = url;

        // Atualiza a classe ativa nos botões
        buttons.forEach(btn => btn.classList.remove('active-btn'));
        if (element) {
            element.classList.add('active-btn');
        } else {
            // Se não houver elemento (carregamento inicial via Hash), procura pelo data-url
            const targetBtn = document.querySelector(`[data-url="${url}"]`);
            if (targetBtn) targetBtn.classList.add('active-btn');
        }

        // Atualiza o Hash da URL sem recarregar a página
        window.location.hash = url.replace('.html', '');
    }

    // Adiciona evento de clique em todos os botões
    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const url = button.getAttribute('data-url');
            navigate(url, button);
        });
    });

    // Lógica para carregar a página correta ao iniciar ou ao usar "Voltar/Avançar"
    const handleHashChange = () => {
        const hash = window.location.hash.replace('#', '');
        if (hash) {
            const url = `${hash}.html`;
            navigate(url);
        } else {
            // Página padrão inicial
            navigate('foco-01.html');
        }
    };

    window.addEventListener('hashchange', handleHashChange);
    
    // Executa no carregamento inicial
    handleHashChange();
});
