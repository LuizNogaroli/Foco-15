// foco-05.js
// Seção 5: Análise do Destinatário (foco-05.html)
// Depende de: formulario.js

(function () {
    'use strict';

    // ══════════════════════════════════════════════════════════════════════════
    // INIT — dispara assim que o DOM estiver pronto, independente de outros
    // scripts. Usa DOMContentLoaded se ainda não disparou, senão executa
    // imediatamente (caso o script seja carregado após o parse do HTML).
    // ══════════════════════════════════════════════════════════════════════════

    function init() {
        const form04 = document.getElementById('form04');
        if (!form04) return; // página errada, encerra silenciosamente

        // Evita dupla inicialização caso init() seja chamado mais de uma vez
        if (form04.dataset.focoInit === '05') return;
        form04.dataset.focoInit = '05';

        // ══════════════════════════════════════════════════════════════════════
        // 1. VALIDAÇÃO EM TEMPO REAL DE TEXTAREAS OBRIGATÓRIAS
        // ══════════════════════════════════════════════════════════════════════

        form04.querySelectorAll('textarea[required]').forEach(function (textarea) {
            textarea.addEventListener('input', function () {
                const isValid = this.value.trim().length > 0;
                this.classList.toggle('field-valid',  isValid);
                this.classList.toggle('field-error', !isValid);
            });
        });

        // ══════════════════════════════════════════════════════════════════════
        // 2. EXIBIÇÃO CONDICIONAL — campo31 (Destinação ativa)
        //    Exibe #bloco31 somente quando "Sim" for selecionado
        // ══════════════════════════════════════════════════════════════════════

        const bloco31 = document.getElementById('bloco31');

        form04.querySelectorAll('input[name="campo31"]').forEach(function (radio) {
            radio.addEventListener('change', function () {
                if (bloco31) {
                    bloco31.style.display = this.value === 'Sim' ? 'flex' : 'none';
                }
            });
        });

        // ══════════════════════════════════════════════════════════════════════
        // 3. EXIBIÇÃO CONDICIONAL — campo33 (Capacidade técnica)
        //    Exibe #bloco33_obs quando qualquer opção válida for selecionada
        // ══════════════════════════════════════════════════════════════════════

        const campo33    = document.getElementById('campo33');
        const bloco33obs = document.getElementById('bloco33_obs');

        if (campo33) {
            campo33.addEventListener('change', function () {
                if (bloco33obs) {
                    bloco33obs.style.display = this.value !== '' ? 'flex' : 'none';
                }
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 4. CHECKBOXES EXCLUSIVOS — campo42[] (Pendências)
        //    "Nenhuma identificada" é mutuamente exclusivo com os demais
        // ══════════════════════════════════════════════════════════════════════

        const cbNenhuma = document.getElementById('campo42-nenhuma');
        const cbOutros  = form04.querySelectorAll('input[name="campo42[]"]:not(#campo42-nenhuma)');

        if (cbNenhuma) {
            cbNenhuma.addEventListener('change', function () {
                if (this.checked) {
                    cbOutros.forEach(function (cb) { cb.checked = false; });
                }
            });

            cbOutros.forEach(function (cb) {
                cb.addEventListener('change', function () {
                    if (this.checked) cbNenhuma.checked = false;
                });
            });
        }

        // ══════════════════════════════════════════════════════════════════════
        // 5. LISTA DINÂMICA DE LINKS/DOCUMENTOS
        // ══════════════════════════════════════════════════════════════════════

        /**
         * Cria um item da lista com createElement para garantir que
         * o evento de remoção funcione em todos os itens, inclusive
         * nos criados dinamicamente após o carregamento da página.
         *
         * @param {string}  inputName    - name do <input> gerado
         * @param {string}  [valorInicial] - valor pré-preenchido (opcional)
         * @param {Element} listEl       - referência ao container da lista
         * @returns {HTMLElement}
         */
        function criarItemLista(inputName, valorInicial, listEl) {
            const item = document.createElement('div');
            item.className     = 'imagem-item';
            item.style.cssText = 'display:flex; gap:6px; align-items:center; margin-top:6px;';

            const input = document.createElement('input');
            input.type         = 'text';
            input.name         = inputName;
            input.placeholder  = 'Link/Documento Anexado';
            input.autocomplete = 'off';
            input.className    = 'imagem-input';
            input.style.flex   = '1';
            if (valorInicial) input.value = valorInicial;

            const btnRemove = document.createElement('button');
            btnRemove.type        = 'button';
            btnRemove.className   = 'btn-remove-imagem';
            btnRemove.title       = 'Remover';
            btnRemove.textContent = '✕';

            // Evento direto no botão — sem delegação, sem innerHTML
            btnRemove.addEventListener('click', function () {
                // Usa listEl passado por parâmetro; fallback para parentElement
                const container = listEl || item.parentElement;
                const itens     = container
                    ? container.querySelectorAll('.imagem-item')
                    : [];

                if (itens.length > 1) {
                    item.remove();
                } else {
                    // Último item: apenas limpa o valor, mantém a linha
                    input.value = '';
                    input.focus();
                }
            });

            item.appendChild(input);
            item.appendChild(btnRemove);
            return item;
        }

        /**
         * Inicializa a lista dinâmica de documentos/links.
         *
         * @param {string} listId    - id do container da lista
         * @param {string} btnId     - id do botão "+ Adicionar"
         * @param {string} inputName - name dos inputs gerados
         * @returns {{ list: Element, inputName: string }|undefined}
         */
        function initDynamicList(listId, btnId, inputName) {
            const list = document.getElementById(listId);
            const btn  = document.getElementById(btnId);

            // Guard: elementos obrigatórios ausentes
            if (!list || !btn) {
                console.warn('[foco-05] initDynamicList: elemento não encontrado →',
                    !list ? '#' + listId : '#' + btnId);
                return;
            }

            // Guard: botão já inicializado (evita duplo registro)
            if (btn.dataset.initialized === 'true') return { list, inputName };
            btn.dataset.initialized = 'true';

            // Clique no botão "+ Adicionar"
            btn.addEventListener('click', function () {
                const novoItem = criarItemLista(inputName, '', list);
                list.appendChild(novoItem);
                novoItem.querySelector('.imagem-input').focus();
            });

            return { list, inputName };
        }

        // ── Inicializa a lista desta seção ───────────────────────────────────
        const listaDocRef = initDynamicList(
            'documentos-list-05',
            'btnAdicionarDocumento05',
            'docs_gerais_05[]'
        );

        // ══════════════════════════════════════════════════════════════════════
        // 6. HELPER — exibe/oculta mensagem de erro
        // ══════════════════════════════════════════════════════════════════════

        function setErro(erroId, invalido) {
            const el = document.getElementById(erroId);
            if (el) el.classList.toggle('visivel', invalido);
        }

        // ══════════════════════════════════════════════════════════════════════
        // 7. VALIDAÇÃO NO SUBMIT
        // ══════════════════════════════════════════════════════════════════════

        const selectsF05 = [
            { id: 'campo33', erro: 'err33' },
        ];

        const radiosF05 = [
            { name: 'campo31', erro: 'err31' },
        ];

        const checkboxesF05 = [
            { name: 'campo42[]', erro: 'err42' },
        ];

        form04.addEventListener('submit', function (e) {
            e.preventDefault();
            let valido = true;

            selectsF05.forEach(function (cfg) {
                const el = document.getElementById(cfg.id);
                if (!el) return;
                const ok = el.value !== '';
                setErro(cfg.erro, !ok);
                if (!ok) valido = false;
            });

            radiosF05.forEach(function (cfg) {
                const marcado = form04.querySelector(
                    'input[name="' + cfg.name + '"]:checked'
                );
                setErro(cfg.erro, !marcado);
                if (!marcado) valido = false;
            });

            checkboxesF05.forEach(function (cfg) {
                const marcados = form04.querySelectorAll(
                    'input[name="' + cfg.name + '"]:checked'
                );
                const ok = marcados.length > 0;
                setErro(cfg.erro, !ok);
                if (!ok) valido = false;
            });

            if (!valido) {
                const primeiroErro = form04.querySelector('.error-msg.visivel');
                if (primeiroErro) {
                    primeiroErro.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                return;
            }

            const dados = new FormData(form04);
            console.log('Seção 5 válida. Dados:', Object.fromEntries(dados.entries()));
            alert('✅ Seção 5 enviada com sucesso!');
        });

        // ══════════════════════════════════════════════════════════════════════
        // 8. BOTÃO LIMPAR
        // ══════════════════════════════════════════════════════════════════════

        const btnLimpar = document.getElementById('btnLimpar');

        if (btnLimpar) {
            btnLimpar.addEventListener('click', function () {
                if (!confirm('Deseja limpar todos os campos?')) return;

                form04.reset();

                // Oculta blocos condicionais
                if (bloco31)    bloco31.style.display    = 'none';
                if (bloco33obs) bloco33obs.style.display = 'none';

                // Remove itens dinâmicos e recria um item vazio
                if (listaDocRef) {
                    const { list, inputName } = listaDocRef;
                    list.innerHTML = '';
                    list.appendChild(criarItemLista(inputName, '', list));
                }

                // Remove marcações de erro/sucesso
                form04.querySelectorAll('.error-msg').forEach(function (el) {
                    el.classList.remove('visivel');
                });
                form04.querySelectorAll('.field-valid, .field-error').forEach(function (el) {
                    el.classList.remove('field-valid', 'field-error');
                });
            });
        }

    } // fim init()

    // ══════════════════════════════════════════════════════════════════════════
    // DISPARO SEGURO
    // Se o DOM já foi parseado (script carregado com defer ou no fim do body),
    // executa imediatamente. Caso contrário, aguarda DOMContentLoaded.
    // ══════════════════════════════════════════════════════════════════════════

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        // DOM já está pronto — executa na próxima microtask para garantir
        // que formulario.js e hints.js já registraram seus próprios listeners
        Promise.resolve().then(init);
    }

})(); // IIFE — sem poluição do escopo global
