// foco-03.js
// Seção 3: Análise do Destinatário (foco-03.html)
// Depende de: formulario.js

document.addEventListener('DOMContentLoaded', function () {

    if (!document.getElementById('form04')) return;

    const form04 = document.getElementById('form04');

    // ══════════════════════════════════════════════════════════════════════════
    // 1. VALIDAÇÃO EM TEMPO REAL DE TEXTAREAS OBRIGATÓRIAS
    // ══════════════════════════════════════════════════════════════════════════

    form04.querySelectorAll('textarea[required]').forEach(function (textarea) {
        textarea.addEventListener('input', function () {
            const isValid = this.value.trim().length > 0;
            this.classList.toggle('field-valid',  isValid);
            this.classList.toggle('field-error', !isValid);
        });
    });

    // ══════════════════════════════════════════════════════════════════════════
    // 2. EXIBIÇÃO CONDICIONAL — campo31 (Destinação ativa)
    //    Exibe #bloco31 somente quando "Sim" for selecionado
    // ══════════════════════════════════════════════════════════════════════════

    const bloco31 = document.getElementById('bloco31');

    form04.querySelectorAll('input[name="campo31"]').forEach(function (radio) {
        radio.addEventListener('change', function () {
            if (bloco31) {
                bloco31.style.display = this.value === 'Sim' ? 'flex' : 'none';
            }
        });
    });

    // ══════════════════════════════════════════════════════════════════════════
    // 3. EXIBIÇÃO CONDICIONAL — campo33 (Capacidade técnica)
    //    Exibe #bloco33_obs quando qualquer opção válida for selecionada
    // ══════════════════════════════════════════════════════════════════════════

    const campo33    = document.getElementById('campo33');
    const bloco33obs = document.getElementById('bloco33_obs');

    if (campo33) {
        campo33.addEventListener('change', function () {
            if (bloco33obs) {
                bloco33obs.style.display = this.value !== '' ? 'flex' : 'none';
            }
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 4. CHECKBOXES EXCLUSIVOS — campo42[] (Pendências)
    //    "Nenhuma identificada" é mutuamente exclusivo com os demais
    // ══════════════════════════════════════════════════════════════════════════

    const cbNenhuma = document.getElementById('campo42-nenhuma');
    const cbOutros  = form04.querySelectorAll('input[name="campo42[]"]:not(#campo42-nenhuma)');

    if (cbNenhuma) {
        cbNenhuma.addEventListener('change', function () {
            if (this.checked) {
                cbOutros.forEach(function (cb) { cb.checked = false; });
            }
        });

        cbOutros.forEach(function (cb) {
            cb.addEventListener('change', function () {
                if (this.checked) cbNenhuma.checked = false;
            });
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 5. LISTA DINÂMICA DE LINKS/DOCUMENTOS
    //    Função reutilizável para qualquer lista do formulário
    // ══════════════════════════════════════════════════════════════════════════

    function initDynamicList(listId, btnId, inputName) {
        const list = document.getElementById(listId);
        const btn  = document.getElementById(btnId);
        if (!list || !btn) return;

        // Delegação: cliques nos botões "✕" de qualquer item da lista
        list.addEventListener('click', function (e) {
            if (!e.target.matches('.btn-remove-imagem')) return;

            const item  = e.target.closest('.imagem-item');
            const itens = list.querySelectorAll('.imagem-item');

            if (itens.length > 1) {
                item.remove();
            } else {
                // Último item: apenas limpa o valor, não remove o elemento
                const input = item.querySelector('.imagem-input');
                if (input) input.value = '';
            }
        });

        // Botão "Adicionar": cria um novo item na lista
        btn.addEventListener('click', function () {
            const newItem = document.createElement('div');
            newItem.className    = 'imagem-item';
            newItem.style.cssText = 'display:flex; gap:6px; align-items:center;';
            newItem.innerHTML = `
                <input
                    type="text"
                    name="${inputName}"
                    placeholder="Faça upload dos documentos adicionais..."
                    autocomplete="off"
                    class="imagem-input"
                    style="flex:1;"
                >
                <button type="button" class="btn-remove-imagem" title="Remover">✕</button>
            `;
            list.appendChild(newItem);
            newItem.querySelector('.imagem-input').focus();
        });
    }

    // Inicializa a lista da seção "Análise do Destinatário"
    initDynamicList(
        'imagens-list-dest_0',
        'btnAdicionarImagemDest_0',
        'imoveis[0][imagens_dest][]'
    );

    // ══════════════════════════════════════════════════════════════════════════
    // 6. HELPER — exibe/oculta mensagem de erro
    // ══════════════════════════════════════════════════════════════════════════

    function setErro(erroId, invalido) {
        const el = document.getElementById(erroId);
        if (el) el.classList.toggle('visivel', invalido);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // 7. VALIDAÇÃO NO SUBMIT
    // ══════════════════════════════════════════════════════════════════════════

    // Selects obrigatórios
    const selectsF03 = [
        { id: 'campo33', erro: 'err33' },
    ];

    // Grupos de radio obrigatórios
    const radiosF03 = [
        { name: 'campo31', erro: 'err31' },
    ];

    // Grupos de checkbox (pelo menos um marcado)
    const checkboxesF03 = [
        { name: 'campo42[]', erro: 'err42' },
    ];

    form04.addEventListener('submit', function (e) {
        e.preventDefault();
        let valido = true;

        selectsF03.forEach(function (cfg) {
            const el = document.getElementById(cfg.id);
            if (!el) return;
            const ok = el.value !== '';
            setErro(cfg.erro, !ok);
            if (!ok) valido = false;
        });

        radiosF03.forEach(function (cfg) {
            const marcado = form04.querySelector('input[name="' + cfg.name + '"]:checked');
            setErro(cfg.erro, !marcado);
            if (!marcado) valido = false;
        });

        checkboxesF03.forEach(function (cfg) {
            const marcados = form04.querySelectorAll('input[name="' + cfg.name + '"]:checked');
            const ok = marcados.length > 0;
            setErro(cfg.erro, !ok);
            if (!ok) valido = false;
        });

        if (!valido) {
            const primeiroErro = form04.querySelector('.error-msg.visivel');
            if (primeiroErro) primeiroErro.scrollIntoView({ behavior: 'smooth', block: 'center' });
            return;
        }

        const dados = new FormData(form04);
        console.log('Seção 3 válida. Dados:', Object.fromEntries(dados.entries()));
        alert('✅ Seção 3 enviada com sucesso!');
    });

    // ══════════════════════════════════════════════════════════════════════════
    // 8. BOTÃO LIMPAR
    // ══════════════════════════════════════════════════════════════════════════

    const listaLinks = document.getElementById('imagens-list-dest_0');
    const btnLimpar  = document.getElementById('btnLimpar');

    if (btnLimpar) {
        btnLimpar.addEventListener('click', function () {
            if (!confirm('Deseja limpar todos os campos?')) return;

            form04.reset();

            // Oculta blocos condicionais
            if (bloco31)    bloco31.style.display    = 'none';
            if (bloco33obs) bloco33obs.style.display = 'none';

            // Remove itens extras da lista, mantendo apenas o primeiro
            if (listaLinks) {
                listaLinks.querySelectorAll('.imagem-item').forEach(function (item, index) {
                    if (index > 0) item.remove();
                    else {
                        // Limpa o valor do item que ficou
                        const input = item.querySelector('.imagem-input');
                        if (input) input.value = '';
                    }
                });
            }

            // Remove marcações de erro/sucesso de todos os campos
            form04.querySelectorAll('.error-msg').forEach(function (el) {
                el.classList.remove('visivel');
            });
            form04.querySelectorAll('.field-valid, .field-error').forEach(function (el) {
                el.classList.remove('field-valid', 'field-error');
            });
        });
    }

}); // fim DOMContentLoaded
