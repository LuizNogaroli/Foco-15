// foco-06.js — Lógica de exibição condicional do FOCO-06

(function () {
    'use strict';

    // ── Utilitário ──────────────────────────────────────────────────────────────
    function mostrar(id) {
        const el = document.getElementById(id);
        if (el) el.style.display = '';
    }
    function ocultar(id) {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    }
    function limparSelect(id) {
        const el = document.getElementById(id);
        if (el) el.value = '';
    }
    function limparTextarea(id) {
        const el = document.getElementById(id);
        if (el) el.value = '';
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SEÇÃO A — Superintendente
    // ══════════════════════════════════════════════════════════════════════════

    const selectA1 = document.getElementById('campoA1');
    const selectA4 = document.getElementById('campoA4');

    // A.1 → exibe blocos A2 e A3 se "Concordo com ressalvas" ou "Discordo"
    if (selectA1) {
        selectA1.addEventListener('change', function () {
            const val = this.value;
            const exibir = val === 'Concordo com ressalvas' || val === 'Discordo';
            if (exibir) {
                mostrar('blocoA2');
                mostrar('blocoA3');
            } else {
                ocultar('blocoA2');
                ocultar('blocoA3');
                limparSelect('campoA2');
                limparTextarea('campoA3');
            }
        });
    }

    // A.4 → exibe alerta informativo se "Não autorizo"
    if (selectA4) {
        selectA4.addEventListener('change', function () {
            if (this.value === 'Não autorizo') {
                mostrar('blocoA4_alerta');
            } else {
                ocultar('blocoA4_alerta');
            }
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SEÇÃO B — Analista Dedes
    // ══════════════════════════════════════════════════════════════════════════

    const selectB4 = document.getElementById('campoB4');
    const selectB6 = document.getElementById('campoB6');

    // B.4 → exibe blocoB5 (regime alternativo) se "Parcialmente adequado" ou "Inadequado"
    if (selectB4) {
        selectB4.addEventListener('change', function () {
            const val = this.value;
            const exibir = val === 'Parcialmente adequado' || val === 'Inadequado';
            if (exibir) {
                mostrar('blocoB5');
            } else {
                ocultar('blocoB5');
                limparSelect('campoB5');
            }
        });
    }

    // B.6 → exibe blocoB7 (ressalvas) se "Favorável com ressalvas"
    if (selectB6) {
        selectB6.addEventListener('change', function () {
            if (this.value === 'Favorável com ressalvas') {
                mostrar('blocoB7');
            } else {
                ocultar('blocoB7');
                limparTextarea('campoB7');
            }
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SEÇÃO C — Diretor(a) Dedes
    // ══════════════════════════════════════════════════════════════════════════

    const selectC1 = document.getElementById('campoC1');

    // C.1 → exibe blocoC2 (ressalvas) se "Aprovo com ressalvas"
    if (selectC1) {
        selectC1.addEventListener('change', function () {
            if (this.value === 'Aprovo com ressalvas') {
                mostrar('blocoC2');
            } else {
                ocultar('blocoC2');
                limparTextarea('campoC2');
            }
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Botão Limpar
    // ══════════════════════════════════════════════════════════════════════════
    const btnLimpar = document.getElementById('btnLimpar');
    if (btnLimpar) {
        btnLimpar.addEventListener('click', function () {
            if (!confirm('Deseja limpar todos os campos do formulário?')) return;
            document.getElementById('form06').reset();

            // Oculta todos os blocos condicionais
            ['blocoA2', 'blocoA3', 'blocoA4_alerta',
             'blocoB5', 'blocoB7',
             'blocoC2'].forEach(ocultar);
        });
    }

})();
