// foco-04.js

// ─────────────────────────────────────────────────────────────────────────────
// Tabela Taxonômica — subitens por código de uso imobiliário (campo52 → campo53)
// RESOLUÇÃO COMGC/SPU/MGI Nº 3/2025
// ─────────────────────────────────────────────────────────────────────────────
const subtiposUso = {
  "0101": [
    { value: "01.01.01", label: "01.01.01 Uso para função administrativa" },
    { value: "01.01.02", label: "01.01.02 Uso para função de controle e fiscalização" },
    { value: "01.01.03", label: "01.01.03 Uso para representação diplomática" },
    { value: "01.01.04", label: "01.01.04 Uso de suporte à função administrativa" },
  ],
  "0102": [
    { value: "01.02.01", label: "01.02.01 Uso para agropecuária e produção florestal" },
    { value: "01.02.02", label: "01.02.02 Uso para aquicultura" },
    { value: "01.02.03", label: "01.02.03 Uso para pesca" },
  ],
  "0103": [
    { value: "01.03.01", label: "01.03.01 Uso para aproveitamento econômico de serviços ambientais ou ecossistêmicos" },
    { value: "01.03.02", label: "01.03.02 Uso para extrativismo vegetal ou mineral" },
    { value: "01.03.03", label: "01.03.03 Uso para unidade especial de proteção ambiental" },
    { value: "01.03.04.01", label: "01.03.04.01 Uso para unidade de proteção integral" },
    { value: "01.03.04.02", label: "01.03.04.02 Uso para unidade de uso sustentável" },
  ],
  "0104": [
    { value: "01.04.01", label: "01.04.01 Uso de apoio operacional cultural, esportivo e de lazer" },
    { value: "01.04.02", label: "01.04.02 Uso cultural" },
    { value: "01.04.03", label: "01.04.03 Uso para lazer e convivência" },
    { value: "01.04.04", label: "01.04.04 Uso para prática esportiva" },
  ],
  "0105": [
    // Sem subitens — apresenta somente o próprio nível
    { value: "01.05", label: "01.05 Uso em eventos de curta duração" },
  ],
  "0106": [
    { value: "01.06.01", label: "01.06.01 Uso habitacional de interesse específico" },
    { value: "01.06.02.01", label: "01.06.02.01 Uso residencial em projeto de provisão habitacional" },
    { value: "01.06.02.02", label: "01.06.02.02 Uso para habitação em assentamento de reforma agrária" },
    { value: "01.06.03.01", label: "01.06.03.01 Uso para habitação em regularização fundiária urbana de interesse social" },
    { value: "01.06.03.02", label: "01.06.03.02 Uso para habitação em regularização fundiária urbana de interesse específico" },
    { value: "01.06.03.03", label: "01.06.03.03 Uso para habitação em regularização fundiária rural" },
  ],
  "0107": [
    { value: "01.07.01", label: "01.07.01 Uso comercial ou de serviços" },
    { value: "01.07.02", label: "01.07.02 Uso para produção industrial" },
  ],
  "0108": [
    { value: "01.08.01.01", label: "01.08.01.01 Uso para passagem de gasoduto ou oleoduto" },
    { value: "01.08.01.02", label: "01.08.01.02 Uso para passagem e instalação de transmissão de energia" },
    { value: "01.08.01.03", label: "01.08.01.03 Uso para produção de energia de fonte renovável" },
    { value: "01.08.01.04", label: "01.08.01.04 Uso para produção de energia de fonte não renovável" },
    { value: "01.08.02.01", label: "01.08.02.01 Uso para captação, tratamento e distribuição de água" },
    { value: "01.08.02.02", label: "01.08.02.02 Uso para coleta, transporte e tratamento de esgoto" },
    { value: "01.08.02.03", label: "01.08.02.03 Uso para coleta, tratamento e destinação de resíduos sólidos" },
    { value: "01.08.02.04", label: "01.08.02.04 Uso para drenagem e manejo de águas pluviais" },
    { value: "01.08.02.05", label: "01.08.02.05 Uso para recursos hídricos" },
    { value: "01.08.03.01", label: "01.08.03.01 Uso para equipamentos de telecomunicações" },
    { value: "01.08.03.02", label: "01.08.03.02 Uso para passagem de rede de telecomunicações" },
    { value: "01.08.04",    label: "01.08.04 Uso em serviço funerário" },
  ],
  "0109": [
    { value: "01.09.01.01", label: "01.09.01.01 Uso de apoio à navegação aérea fora do aeródromo" },
    { value: "01.09.01.02", label: "01.09.01.02 Uso para operação de aeródromo com aeroporto" },
    { value: "01.09.01.03", label: "01.09.01.03 Uso para operação de aeródromo sem aeroporto" },
    { value: "01.09.02.01", label: "01.09.02.01 Uso para circulação aquaviária" },
    { value: "01.09.02.02", label: "01.09.02.02 Uso de estrutura náutica" },
    { value: "01.09.02.03", label: "01.09.02.03 Uso para instalação portuária dentro da área do porto organizado" },
    { value: "01.09.02.04", label: "01.09.02.04 Uso para instalação portuária fora da área do porto organizado" },
    { value: "01.09.03.01", label: "01.09.03.01 Uso para apoio operacional ferroviário e metroviário" },
    { value: "01.09.03.02", label: "01.09.03.02 Uso para faixa de domínio ferroviário e metroviário" },
    { value: "01.09.04.01", label: "01.09.04.01 Uso para apoio operacional rodoviário" },
    { value: "01.09.04.02", label: "01.09.04.02 Uso para faixa de domínio viário" },
  ],
  "0110": [
    { value: "01.10", label: "01.10 Uso multifinalitário em projeto de requalificação urbana" },
  ],
  "0111": [
    { value: "01.11.01", label: "01.11.01 Uso por comunidade quilombola" },
    { value: "01.11.02", label: "01.11.02 Usufruto indígena" },
    { value: "01.11.03", label: "01.11.03 Uso por outros povos e comunidade tradicional" },
  ],
  "0112": [
    { value: "01.12.01", label: "01.12.01 Uso para unidade de ensino infantil e básico" },
    { value: "01.12.02", label: "01.12.02 Uso para unidade de ensino profissional e tecnológico" },
    { value: "01.12.03", label: "01.12.03 Uso para unidade de ensino superior" },
    { value: "01.12.04", label: "01.12.04 Uso para unidade de pesquisa e desenvolvimento tecnológico" },
  ],
  "0113": [
    { value: "01.13.01", label: "01.13.01 Uso em serviços de abastecimento e segurança alimentar e nutricional" },
    { value: "01.13.02", label: "01.13.02 Uso em serviços de acolhimento e proteção social" },
    { value: "01.13.03", label: "01.13.03 Uso em serviços de promoção de direitos e cidadania" },
  ],
  "0114": [
    { value: "01.14.01", label: "01.14.01 Uso para apoio operacional e vigilância em saúde" },
    { value: "01.14.02", label: "01.14.02 Uso para unidade de atenção especializada à saúde" },
    { value: "01.14.03", label: "01.14.03 Uso para unidade de atenção primária à saúde" },
    { value: "01.14.04", label: "01.14.04 Uso para unidade hospitalar" },
  ],
  "0115": [
    { value: "01.15.01", label: "01.15.01 Uso residencial no interesse do serviço" },
    { value: "01.15.02", label: "01.15.02 Uso residencial obrigatório" },
    { value: "01.15.03", label: "01.15.03 Uso residencial voluntário de servidor da União" },
  ],
  "0116": [
    { value: "01.16.01", label: "01.16.01 Uso para defesa nacional" },
    { value: "01.16.02", label: "01.16.02 Uso para equipamento policial" },
    { value: "01.16.03", label: "01.16.03 Uso para equipamento prisional" },
  ],
  "0117": [
    { value: "01.17", label: "01.17 Uso religioso" },
  ],
  "0118": [
    { value: "01.18", label: "01.18 Sem informação" },
  ],
  "0119": [
    { value: "01.19", label: "01.19 Sem uso definido/vinculado" },
  ],
};

// ─────────────────────────────────────────────────────────────────────────────
// Lógica de cascata: campo52 → campo53
// ─────────────────────────────────────────────────────────────────────────────
(function () {
  const sel52 = document.getElementById("campo52");
  const sel53 = document.getElementById("campo53");

  function popularSubtipos(codigoNivel1) {
    // Limpa opções existentes
    sel53.innerHTML = "";

    if (!codigoNivel1 || !subtiposUso[codigoNivel1]) {
      sel53.innerHTML = '<option value="">Selecione primeiro o tipo de uso imobiliário...</option>';
      sel53.disabled = true;
      return;
    }

    // Opção placeholder
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Selecione o uso específico...";
    placeholder.selected = true;
    sel53.appendChild(placeholder);

    // Popula com os subitens correspondentes
    subtiposUso[codigoNivel1].forEach(function (item) {
      const opt = document.createElement("option");
      opt.value = item.value;
      opt.textContent = item.label;
      sel53.appendChild(opt);
    });

    sel53.disabled = false;
  }

  // Listener no campo de nível 1
  sel52.addEventListener("change", function () {
    popularSubtipos(this.value);
    // Reseta valor do campo53 ao trocar o nível 1
    sel53.value = "";
  });

  // Inicialização: garante estado correto ao carregar
  popularSubtipos(sel52.value);
})();



document.addEventListener('DOMContentLoaded', function () {

    // =========================================================
    // BLOCOS CONDICIONAIS — Dropdowns
    // =========================================================
    function configurarBlocoDropdown(selectId, blocoId) {
        const select = document.getElementById(selectId);
        const bloco = document.getElementById(blocoId);
        if (!select || !bloco) return;

        function atualizar() {
            const visivel = select.value !== '';
            bloco.style.display = visivel ? '' : 'none';
            if (!visivel) {
                const ta = bloco.querySelector('textarea');
                if (ta) ta.value = '';
            }
        }

        select.addEventListener('change', atualizar);
        atualizar();
    }

    // =========================================================
    // BLOCOS CONDICIONAIS — Radio buttons
    // =========================================================
    function configurarBlocoRadio(radioName, blocoId, valorGatilho) {
        const radios = document.querySelectorAll(`input[type="radio"][name="${radioName}"]`);
        const bloco = document.getElementById(blocoId);
        if (!radios.length || !bloco) return;

        function atualizar() {
            const selecionado = document.querySelector(`input[type="radio"][name="${radioName}"]:checked`);
            const visivel = selecionado && selecionado.value === valorGatilho;
            bloco.style.display = visivel ? '' : 'none';
            if (!visivel) {
                const ta = bloco.querySelector('textarea');
                if (ta) ta.value = '';
            }
        }

        radios.forEach(r => r.addEventListener('change', atualizar));
        atualizar();
    }

    // =========================================================
    // INICIALIZAR CAMPOS CONDICIONAIS
    // =========================================================
    configurarBlocoDropdown('campo51', 'bloco51_obs');
    configurarBlocoDropdown('campo55', 'bloco55_obs');
    configurarBlocoDropdown('campo58', 'bloco58_obs');
    configurarBlocoDropdown('campo510', 'bloco510_obs');
    configurarBlocoDropdown('campo511', 'bloco511_obs');
    configurarBlocoRadio('campo54', 'bloco54', 'Sim');

    // =========================================================
    // LISTA DINÂMICA DE DOCUMENTOS — genérica e reutilizável
    // =========================================================
    function configurarListaDinamica(listWrapperId, btnAdicionarId, nomeInput) {
        const listWrapper = document.getElementById(listWrapperId);
        const btnAdicionar = document.getElementById(btnAdicionarId);
        if (!listWrapper || !btnAdicionar) return;

        // Remover ou limpar item
        listWrapper.addEventListener('click', function (e) {
            if (e.target.classList.contains('btn-remove-imagem')) {
                const itens = listWrapper.querySelectorAll('.imagem-item');
                if (itens.length > 1) {
                    e.target.closest('.imagem-item').remove();
                } else {
                    // Último item: apenas limpa o valor
                    const input = e.target.closest('.imagem-item').querySelector('.imagem-input');
                    if (input) input.value = '';
                }
            }
        });

        // Adicionar novo item
        btnAdicionar.addEventListener('click', function () {
            const novoItem = document.createElement('div');
            novoItem.className = 'imagem-item';
            novoItem.style.cssText = 'display:flex; gap:6px; align-items:center;';
            novoItem.innerHTML = `
                <input
                    type="text"
                    name="${nomeInput}"
                    placeholder="Faça upload dos documentos adicionais..."
                    autocomplete="off"
                    class="imagem-input"
                    style="flex:1;"
                >
                <button type="button" class="btn-remove-imagem" title="Remover">✕</button>
            `;
            listWrapper.appendChild(novoItem);
            // Foca no novo campo
            novoItem.querySelector('.imagem-input').focus();
        });
    }

    // Inicializar a lista de documentos da seção 4
    configurarListaDinamica(
        'imagens-list-rest_0',
        'btnAdicionarImagemRest_0',
        'imoveis[0][imagens_rest][]'
    );

    // =========================================================
    // BOTÃO LIMPAR
    // =========================================================
    const btnLimpar = document.getElementById('btnLimpar');
    if (btnLimpar) {
        btnLimpar.addEventListener('click', function () {
            if (!confirm('Deseja limpar todos os campos?')) return;

            const form = document.getElementById('form04');
            if (form) form.reset();

            // Ocultar e limpar todos os blocos condicionais
            ['bloco51_obs', 'bloco55_obs', 'bloco58_obs', 'bloco510_obs', 'bloco511_obs', 'bloco54'].forEach(function (id) {
                const el = document.getElementById(id);
                if (el) {
                    el.style.display = 'none';
                    const ta = el.querySelector('textarea');
                    if (ta) ta.value = '';
                }
            });

            // Restaurar lista de documentos com um único item vazio
            const listWrapper = document.getElementById('imagens-list-rest_0');
            if (listWrapper) {
                listWrapper.innerHTML = `
                    <div class="imagem-item" style="display:flex; gap:6px; align-items:center;">
                        <input
                            type="text"
                            name="imoveis[0][imagens_rest][]"
                            value=""
                            placeholder="Faça upload dos documentos adicionais..."
                            autocomplete="off"
                            class="imagem-input"
                            style="flex:1;"
                        >
                        <button type="button" class="btn-remove-imagem" title="Remover">✕</button>
                    </div>
                `;
            }
        });
    }

});
